<?php 
$con=mysqli_connect("localhost","root","","blog");

if (!$con) {
    die("Something went wrong. Database is not correct;");
}
?>